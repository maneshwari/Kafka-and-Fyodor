# The Literary Soul

> *"There is infinite hope — but not for us."* — Kafka  
> *"Love in action is a harsh and dreadful thing."* — Dostoevsky

A personality portrait built around six of literature's most uncompromising thinkers: **Kafka, Nietzsche, Camus, Dostoevsky, Hesse, and Sartre**. This is not a quiz about your favorite color. It is 10 questions designed to reveal how you actually move through the world when no one is watching.

**[Live Demo](https://maneshwari.github.io/Kafka-and-Fyodor/)** *(coming soon after deployment)*

---

## What This Is

A philosophical personality quiz that maps you to one of **12 literary archetypes**:

| Author | Archetypes |
|--------|-----------|
| **Kafka** | Josef K. (The Accused) · Gregor Samsa (The Transformed) |
| **Nietzsche** | Zarathustra (The Overcomer) · The Dionysian (The Affirmer) |
| **Camus** | Meursault (The Stranger) · Sisyphus (The Revolter) |
| **Dostoevsky** | Raskolnikov (The Transgressor) · Alyosha (The Luminous) · The Underground Man (The Hyper-Conscious) |
| **Hesse** | Demian (The Seeker) · Harry Haller/Steppenwolf (The Divided) |
| **Sartre** | Roquentin (The Nauseated) |

---

## Features

### 🎯 10 Penetrating Questions
Not "what's your favorite season" — but situations that force genuine self-recognition:
- *You are at a funeral and feel nothing. What do you do with that?*
- *At 3am, what does that self want that the daytime self won't admit?*
- *At the end of your life — what did you protect most?*

### 🧠 Your Complete Portrait
- **Primary Archetype** — who you are
- **Behavioral Pattern** — how you move
- **Core Fear** — what you protect against
- **Hidden Strength** — what you don't see in yourself
- **Relationship Style** — how you bond
- **Shadow Self** — the part you haven't faced

### ⚡ Divided Soul Detection
If your answers don't converge cleanly, we tell you. You inhabit more than one world — and we name the tension between them.

### 🤝 Full Compatibility Matrix
Every archetype scored against every other — **132 hand-written pairings** with relationship statuses:
- **◈◈ Soulmate** (82–100) — Rare recognition
- **◇◇ Dark Mirror** (65–81) — You see yourself in them
- **⚡ Magnetic Clash** (48–64) — Intense, combustible
- **⬡ Difficult Truth** (30–47) — Uncomfortable, necessary
- **◇ Ships at Night** (0–29) — Parallel worlds

Examples:
- *Alyosha × Gregor (90):* "Alyosha loves without condition. For Gregor, who has only known conditional love, this is almost unbearable."
- *Underground Man × Roquentin (88):* "Two people who see through everything and are paralyzed by the seeing. They will spend hours on a single sentence following it down."

### 📥 Downloadable Portrait Card
Your result as a beautiful **SVG card** — scales to any size, opens anywhere, shareable everywhere.

### 🔍 Compare Mode
Place any two archetypes side-by-side to see their traits, tensions, and registered philosophical clashes.

---

## Tech Stack

- **React 18** — functional components, hooks
- **Vite** — lightning-fast dev server
- **Zero dependencies** — pure React, no UI libraries
- **SVG export** — native browser APIs, no Canvas hacks

---

## Getting Started

### Local Development

```bash
# Clone the repository
git clone https://github.com/maneshwari/Kafka-and-Fyodor.git
cd Kafka-and-Fyodor

# Install dependencies
npm install

# Run development server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for Production

```bash
npm run build
```

Output goes to `/dist` — ready to deploy to GitHub Pages, Vercel, Netlify, or anywhere static sites live.

---

## Deploying to GitHub Pages

1. **Enable GitHub Pages** in your repo settings:
   - Go to **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: **`gh-pages`** / `root`

2. **Build and deploy:**

```bash
npm run build

# Install gh-pages if you don't have it
npm install -g gh-pages

# Deploy
gh-pages -d dist
```

Your site will be live at: `https://maneshwari.github.io/Kafka-and-Fyodor/`

---

## Project Structure

```
Kafka-and-Fyodor/
├── src/
│   ├── App.jsx          # Main application (all 12 archetypes, questions, logic)
│   └── main.jsx         # React entry point
├── public/              # Static assets (if any)
├── index.html           # HTML shell
├── vite.config.js       # Vite configuration
├── package.json         # Dependencies & scripts
└── README.md            # This file
```

---

## Philosophy

This project was not built to be kind. Kafka and Dostoevsky were not kind. They were honest — and that honesty is what makes their work endure.

The questions are designed to make you pause. Not because the choice is hard, but because it requires you to admit something about yourself you usually avoid. The archetypes are not flattering. They are diagnostic.

If you come out of this quiz feeling **uncomfortable** — good. That means it worked.

---

## License

MIT License — use it, fork it, remix it, share it.

---

## Acknowledgments

Built with darkness and care.  
Philosophical content drawn from primary texts and secondary scholarship on Kafka, Nietzsche, Camus, Dostoevsky, Hesse, and Sartre.

*"It was late in the evening when K. arrived."*
