# Deployment Guide

## Quick Deploy to GitHub Pages

### Step 1: Push to GitHub

```bash
cd Kafka-and-Fyodor
git init
git add .
git commit -m "Initial commit: The Literary Soul"
git branch -M main
git remote add origin https://github.com/maneshwari/Kafka-and-Fyodor.git
git push -u origin main
```

### Step 2: Deploy

```bash
# Install gh-pages
npm install -g gh-pages

# Build the project
npm run build

# Deploy to GitHub Pages
gh-pages -d dist
```

### Step 3: Enable GitHub Pages

1. Go to your repo: `https://github.com/maneshwari/Kafka-and-Fyodor`
2. Click **Settings** → **Pages**
3. Under **Source**, select: **Deploy from a branch**
4. Branch: **`gh-pages`** / folder: **`/ (root)`**
5. Click **Save**

Your site will be live at: **https://maneshwari.github.io/Kafka-and-Fyodor/**

---

## Alternative: Deploy to Vercel (Easiest)

1. Push your code to GitHub (see Step 1 above)
2. Go to [vercel.com](https://vercel.com)
3. Click **"New Project"**
4. Import your `Kafka-and-Fyodor` repository
5. Vercel auto-detects Vite — just click **Deploy**

Done. Your site is live with a custom domain in ~60 seconds.

---

## Alternative: Deploy to Netlify

```bash
# Build the project
npm run build

# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod --dir=dist
```

Or use Netlify's drag-and-drop: build locally, then drag the `/dist` folder to [app.netlify.com/drop](https://app.netlify.com/drop).

---

## Local Development

```bash
npm install
npm run dev
```

Visit [http://localhost:5173](http://localhost:5173)

---

## Troubleshooting

### GitHub Pages shows 404
- Make sure `vite.config.js` has `base: '/Kafka-and-Fyodor/'`
- Check that GitHub Pages is enabled and set to `gh-pages` branch
- Wait 2-3 minutes after deployment — GitHub can be slow

### Build fails
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Can't push to GitHub
You need a Personal Access Token. Go to:
`GitHub → Settings → Developer Settings → Personal Access Tokens → Generate New Token`

Give it `repo` permissions, then use the token as your password when pushing.
